For exercises https://stepik.org/course/143445/syllabus
