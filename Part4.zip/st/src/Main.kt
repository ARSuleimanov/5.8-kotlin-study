import kotlin.math.*

//public const val PI: Double = 3.141592653589793
fun main() {
  exercise_1()
}

fun Boolean.toDouble():Double  {
    if (this) return 1.0 else return 0.0
}

fun exercise_1(){
    //создание треугольника
    val t=triangle(point(-3.0,-3.0), point(0.0,6.0), point(3.0,-3.0))

    t.print() //вывод точек треугольника
    println("Периметр треугольника=${t.perimeter()}")
    println("Площадь треугольника=${t.AreaValue()}")
    println("Центр масс треугольника: ${t.centr_w().show()}")

    val angle=30.0  //задание угла поворота
    t.rotate(angle) //поворот треугольника на заданный угол вокруг центра масс

    println("\nповернутый треугольник на угол $angle°:")
    t.print()
    println("Периметр треугольника=${t.perimeter()}")
    println("Площадь треугольника=${t.AreaValue()}")
    println("Центр масс треугольника: ${t.centr_w().show()}")

}

//Класс - точка
class point(var x:Double=0.0, var y:Double=0.0) {

    //Метод определения длины отрезка заданного текущей точкой и передаваемой в качестве параметра
    fun lenght(p:point):Double{
        return (sqrt( (p.x-x)*(p.x-x)+(p.y-y)*(p.y-y)))
    }

    //метод определения - коллинеарности: лежат точки (текущая и две передаваемые) на одной прямой или нет
    fun collinear(p1:point, p2:point):Boolean {
        return(abs((x-p1.x)/(y-p1.y))==abs((x-p2.x)/(y-p2.y)))
    }

    //метод возвращает координаты точки
    fun show():String {
        return("Точка x=$x, y=$y")
    }
    //возвращает угол в градусах для отрезка АВ относительно оси абцисс, где точка А - текущая точка, B - передаваемая
    fun angle(B:point):Double{
        return (((acos((B.x-x)/lenght(B)))*180/ kotlin.math.PI)*(1-2*(y>B.y).toDouble()))

    }
    // функция возвращает повернутую точку B по окружности на заданный угол относительно текущей
    fun rotate(B:point, degree:Double):point{
        println(angle(B))
        val absRad:Double = (angle(B)+degree)*kotlin.math.PI/180

        val len = lenght(B)
        return (point(x+ len*cos(absRad),y+len*sin(absRad)))
    }
}

//Класс - треугольников
class triangle (private val A:point=point(), private val B:point = point(),private val C:point = point()) {
    //проверка на коллинеарность всех точек при создании
    init {
        require(!(A.collinear(B,C))){"точки не должны находиться на одной прямой"}
    }
    // метод переопределения координат для точек, с проверкой коллинеарности
    fun set(a:point=A, b:point=B, c:point=C){
        require(!(a.collinear(b,c))){"точки не должны находиться на одной прямой"}
        A.x=a.x
        A.y=a.y
        B.x=b.x
        B.y=b.y
        C.x=c.x
        C.y=c.y
    }
//Метод поворота треугольника вокруг центра масс на указанное количество градусов
    fun rotate(degree:Double) {
        val c=centr_w()             //определение центра масс
        val A1=c.rotate(A,degree)   //поворот каждой точки относительно него
        val B1=c.rotate(B,degree)
        val C1=c.rotate(C,degree)
        set(A1,B1,C1)               //переопределение координат вершин треугольника
    }

    //метод определения центр масс треугольника
    fun centr_w():point {
        return point((A.x+B.x+C.x)/3, (A.y+B.y+C.y)/3)
    }

    //метод вывода координат вершин треугольника
    fun print(){
        println("A: x=${A.x}, y=${A.y}  \nB: x=${B.x}, y=${B.y}\nC: x=${C.x}, y=${C.y}")
    }

    //определение периметра - сумма всех сторон
    fun perimeter():Double{
        return(A.lenght(B)+B.lenght(C)+C.lenght(A))
    }

//    вычисление площади треугольника по формуе Герона
//    a,b,c - длина сторон треугольника
//    p=(a+b+c)/2  - полупериметер
//    S=sqrt(p(p-a)(p-b)(p-c))
    fun AreaValue():Double {
        val a:Double=A.lenght(B)
        val b:Double=B.lenght(C)
        val c:Double=C.lenght(A)
        val p:Double=perimeter()/2
        return (sqrt(p*(p-a)*(p-b)*(p-c)))

    }
}
