import javax.xml.crypto.Data

fun main() {
    val num=2   //Число
    val power=8 //Степень
    val l:(Int)->Unit={ a:Int-> println(a) }

    println("Возведение $num в степень $power, ответ: ${num.Power(power)}")
    print("(Lambda)Возведение $num в степень $power, ответ:")
    num.PowerL(power,l)


    1.displayTypeInfo()
    "а".displayTypeInfo()
    true.displayTypeInfo()

    DataType.DoubleType(1.4).displayTypeInfo()
    DataType.UnitType().displayTypeInfo()
}


fun Int.Power(Power:Int):Int{
    var res=1
    for (i in 1..Power) res*=this
    return (res)
}

fun Int.PowerL(Power:Int, f:(Int)->Unit){
    var res=1
    for (i in 1..Power) res*=this
    f(res)
}

fun <T> T.displayTypeInfo(){
    when (this) {
        is String -> println("Это String")
        is Int -> println("Это Int")
        is DataType -> this.displayDataTypeInfo()
        else -> println("Тип у $this не известен")
    }
}


sealed class DataType(){
    class DoubleType(val value:Double):DataType()
    class UnitType():DataType()

}
fun DataType.displayDataTypeInfo(){

    when (this) {
        is DataType.DoubleType -> println("Это DoubleType со значением, ${this.value}")
        is DataType.UnitType -> println("Это Unit")
        else -> println("Это просто DataType")
    }

}